"""Offline verification. Run from the extracted evidence directory (Python 3, stdlib only)."""
import json,collections
from pathlib import Path
B=Path(__file__).resolve().parent
M='CqPsrJcJq9DLefXZyWmj7vmvANYYkCoK94poJcZxpump';WS='So11111111111111111111111111111111111111112'
read=lambda f:json.loads((B/f).read_text())
W=(B/'wallets.txt').read_text().splitlines();C=set(read('cluster-wallets.json'));R=read('ledger.json');P=read('prep-costs.json');balances=read('cluster-current-token-balances.json')
cache={}
def tx(s):
 if s not in cache:cache[s]=read('transactions/'+s+'.json')
 return cache[s]
def deltas(t,mint):
 d=collections.defaultdict(int)
 for side,sign in [('preTokenBalances',-1),('postTokenBalances',1)]:
  for b in t['meta'][side]:
   if b['mint']==mint:d[b['owner']]+=sign*int(b['uiTokenAmount']['amount'])
 return d
for r in R:
 t=tx(r['signature']);m=t['meta'];ks=[k['pubkey'] for k in t['transaction']['message']['accountKeys']];j=ks.index(r['wallet'])
 assert m['err'] is None
 assert deltas(t,M)[r['wallet']]==r['token_raw']
 assert m['postBalances'][j]-m['preBalances'][j]==r['native_lamports']
 assert deltas(t,WS)[r['wallet']]==r['wsol_lamports']
 assert r['native_lamports']+r['wsol_lamports']==r['cash_lamports']
for p in P:
 t=tx(p['signature']);m=t['meta'];ks=[k['pubkey'] for k in t['transaction']['message']['accountKeys']]
 native=sum(m['postBalances'][i]-m['preBalances'][i] for i,k in enumerate(ks) if k in C);ws=deltas(t,WS)
 assert native+sum(ws[w] for w in C)==p['cash_lamports']
for w in C:
 balance=sum(int(a['account']['data']['parsed']['info']['tokenAmount']['amount']) for a in balances[w]['value'])
 assert sum(r['token_raw'] for r in R if r['wallet']==w)==balance
net=sum(r['cash_lamports'] for r in R)+sum(p['cash_lamports'] for p in P)
assert net==190766018272
rootnet=sum(r['cash_lamports'] for r in R if r['root'])+sum(p['cash_lamports'] for p in P if p['payer'] in W)
assert rootnet==377509473693
S=read('scope-refreshed.json');I={h['signature']:(h['slot'],h['transactionIndex']) for hs in S['histories'].values() for h in hs}
F=read('launch-funding-proof.json')
for f in F:
 assert I[f['signature']]<I[f['first_buy_signature']]
 t=tx(f['signature']);m=t['meta'];ks=[k['pubkey'] for k in t['transaction']['message']['accountKeys']]
 j=ks.index(f['wallet']);k=ks.index(f['source'])
 assert m['postBalances'][j]-m['preBalances'][j]==f['received_lamports']
 assert m['postBalances'][k]-m['preBalances'][k]==f['source_delta_lamports']<0
assert set(f['number'] for f in F)==set(range(1,31))
Q=read('buyback-proof.json')
for q in Q:
 for label in ['source_sale','funding','buy']:assert I[q[label+'_signature']]==(q[label+'_slot'],q[label+'_index'])
 assert (q['source_sale_slot'],q['source_sale_index'])<(q['funding_slot'],q['funding_index'])<(q['buy_slot'],q['buy_index'])
 assert q['source_sale_slot']==q['funding_slot']==q['buy_slot']
 assert any(r['signature']==q['source_sale_signature'] and r['wallet']==q['source'] and r['token_raw']<0 and r['cash_lamports']>0 for r in R)
 assert any(r['signature']==q['buy_signature'] and r['wallet']==q['destination'] and r['token_raw']>0 and r['cash_lamports']<0 for r in R)
 t=tx(q['funding_signature']);ks=[k['pubkey'] for k in t['transaction']['message']['accountKeys']];m=t['meta'];j=ks.index(q['destination']);k=ks.index(q['source'])
 assert abs((m['postBalances'][j]-m['preBalances'][j])/1e9-q['funding_SOL'])<1e-10
 assert m['postBalances'][k]<m['preBalances'][k]
assert len(Q)==68 and sum(q['adjacent'] for q in Q)==63
if (B/'complete-routes.json').exists():
 D=read('complete-routes.json')
 for e in D['edges']:
  t=tx(e['signature']);ks=[k['pubkey'] for k in t['transaction']['message']['accountKeys']];m=t['meta'];j=ks.index(e['destination']);k=ks.index(e['source'])
  assert m['err'] is None and m['postBalances'][j]-m['preBalances'][j]==e['lamports']
  assert m['preBalances'][k]-m['postBalances'][k]>=e['lamports']
 print('Verified SOL edges:',len(D['edges']),'Remaining frontier:',len(D['front']))
print('PASS: 326 ledger rows, 98 reconciled token balances, 30 funding paths, 68 same-slot rebuy chains.')
print('30 wallets net lamports:',rootnet,'98 wallets net lamports:',net)

if (B/'audit-final-summary.json').exists():
 A=read('audit-final-summary.json');seeds=read('cash-exits.json');paths=read('complete-path-summary.json')
 assert not D['front'] and not D['traders'] and not D['incomplete']
 fees=sum(tx(sig)['meta']['fee'] for sig in {e['signature'] for e in D['edges']}-{e['signature'] for e in seeds})
 assert fees==A['route_network_fees_lamports']
 costs=0
 for e in D['edges']:
  if e['signature'] in {x['signature'] for x in seeds}:continue
  t=tx(e['signature']);m=t['meta'];ks=[k['pubkey'] for k in t['transaction']['message']['accountKeys']];j=ks.index(e['source'])
  costs+=m['preBalances'][j]-m['postBalances'][j]-e['lamports']
 assert costs==A['route_fees_lamports']==sum(p['intermediate_cost_lamports'] for p in paths)
 assert costs-fees==A['route_small_payments_lamports']
 assert sum(p['initial_lamports'] for p in paths)==sum(e['lamports'] for e in seeds)
 assert sum(A['terminal_totals'].values())==sum(p['arrived_lamports'] for p in paths)
 assert sum(A['terminal_counts'].values())==len(paths)==107
 assert A['base_cash_result_lamports']==net
 assert A['extra_expenses_lamports']==sum(e['lamports'] for e in read('extra-expenses.json'))
 assert A['conservative_scenario_lamports']==net-A['extra_expenses_lamports']-costs-A['small_untraced_exits_lamports']
 print('PASS: all 107 exit paths closed, route fees and conservative scenario reconciled.')

if (B/'route-history-snapshots.json').exists():
 H=read('route-history-snapshots.json')
 for w,start in D['seen'].items():
  for h in H[w]:
   if (h['blockTime'] or 0)<start:continue
   t=tx(h['signature'])
   assert deltas(t,M)[w]==0, ('Unexpected SHYFT movement',w,h['signature'])
 print('PASS: archived intermediate histories contain no SHYFT balance movements after receipt.')
